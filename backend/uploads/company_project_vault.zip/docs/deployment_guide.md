# Enterprise Deployment Guide
1. Ensure MFA Step-up
2. Verify Device Posture